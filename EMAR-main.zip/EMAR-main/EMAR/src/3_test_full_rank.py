import json
import logging
import os

import hydra
import torch
from tqdm import tqdm
from indxr import Indxr
from omegaconf import DictConfig

from model.model import BiEncoder
from model.utils import seed_everything

from ranx import Run, Qrels, compare

logger = logging.getLogger(__name__)


def get_bert_rerank(data, model, doc_embedding, id_to_index):
    bert_run = {}
    model.eval()
    for d in tqdm(data, total=len(data)):
        with torch.no_grad():
            q_embedding = model.query_encoder([d['text']])

        bm25_docs = d['bm25_doc_ids']
        d_embeddings = doc_embedding[torch.tensor([int(id_to_index[x]) for x in bm25_docs])]
        bert_scores = torch.einsum('xy, ly -> x', d_embeddings, q_embedding)
        bert_run[d['id']] = {doc_id: bert_scores[i].item() for i, doc_id in enumerate(bm25_docs)}

    return bert_run

def get_full_bert_rank(data, model, doc_embedding, id_to_index, k=100):
    bert_run = {}
    index_to_id = {ind: _id for _id, ind in id_to_index.items()}
    model.eval()
    for d in tqdm(data, total=len(data)):
        with torch.no_grad():
            q_embedding = model.query_encoder([d['text']])
        
        bert_scores = torch.einsum('xy, ly -> x', doc_embedding, q_embedding)
        index_sorted = torch.argsort(bert_scores, descending=True)
        top_k = index_sorted[:k]
        bert_ids = [index_to_id[int(_id)] for _id in top_k]
        bert_scores = bert_scores[top_k]
        bert_run[d['id']] = {doc_id: bert_scores[i].item() for i, doc_id in enumerate(bert_ids)}
        
        
    return bert_run

@hydra.main(config_path="../conf", config_name="config", version_base=None)
def main(cfg: DictConfig):
    data_dir = cfg.dataset.data_dir
    model_dir = cfg.dataset.model_dir
    runs_dir = cfg.dataset.runs_dir
    os.makedirs(runs_dir, exist_ok=True)

    logging_dir = cfg.logging.logging_dir
    logging_file = os.path.join(logging_dir, '3_test_full.log')
    logging.basicConfig(
        filename=logging_file,
        filemode='a',
        format='%(asctime)s,%(msecs)d %(name)s %(levelname)s %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S',
        level=logging.INFO
    )

    seed_everything(cfg.general.seed)

    model = BiEncoder(
        cfg.model.model_name,
        cfg.model.tokenizer_name,
        cfg.model.max_tokens,
        cfg.model.normalize,
        cfg.model.pooling_mode,
        cfg.model.device
    )
    model.load(os.path.join(model_dir,f'{cfg.model.name}.pt'))
    model.eval()
    
    doc_embedding = torch.load(os.path.join(cfg.dataset.embedding_dir, f'{cfg.model.name}.pt')).to(cfg.model.device)
    with open(os.path.join(cfg.dataset.embedding_dir, f'{cfg.model.name}.json'), 'r') as f:
        id_to_index = json.load(f)

    
    
    split = 'test'
    query_data = Indxr(os.path.join(data_dir, split, 'queries.jsonl'), key_id='id')
    bert_run = get_full_bert_rank(query_data, model, doc_embedding, id_to_index)

    ranx_qrels = Qrels.from_file(os.path.join(data_dir, split, 'qrels.json'))
    ranx_run = Run(bert_run, 'Neural')
    
    models = [ranx_run]
    evaluation_report = compare(
        ranx_qrels,
        models,
        ['map@100', 'mrr@10', 'recall@100', 'ndcg@10', 'precision@1', 'ndcg@3']
    )

    print(evaluation_report)
    logging.info(f"Results:\n{evaluation_report}")

if __name__ == '__main__':
    main()